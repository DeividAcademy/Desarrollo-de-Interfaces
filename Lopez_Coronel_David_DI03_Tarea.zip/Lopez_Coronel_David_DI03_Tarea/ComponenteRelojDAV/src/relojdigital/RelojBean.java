package relojdigital;

import java.beans.*;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;
import javax.swing.JLabel;

/**
 *
 * @author David López Coronel
 */
//Vamos a extender la clase RelojBean, de un 'JLabel' porque es un componente que tiene que mostrar algo, como la hora, es ideal este JLabel.
public class RelojBean extends JLabel implements Serializable {

    //Establezco las propiedades
    private boolean formato24;
    private Alarma alarma;    
    private AlarmaListener alarmaListener;

    //Formato 24h con 'HH' / y el formato 12h con 'hh'
    private SimpleDateFormat sdf24h = new SimpleDateFormat("HH:mm:ss");
    private SimpleDateFormat sdf12h = new SimpleDateFormat("hh:mm:ss a");    

    //Constructor 'RelojBean' sin parámetros.
    public RelojBean() {

        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                //Para mostrar la hora solo hace falta está parte del código 'run'
                Date horaActual = new Date();
                if (formato24) {
                    setText(sdf24h.format(horaActual));
                } else {
                    setText(sdf12h.format(horaActual));
                }
                //A partir de aquí pues sería ya para la alarma.                
                if (alarma != null) {
                    if (alarma.isActiva() && horasCoinciden(horaActual, alarma.getHoraAlarma())) {
                        if (alarmaListener != null) {
                            alarmaListener.suenaAlarma();
                        }
                    }
                }

            }
        }, 0, 1000); // 0 segundos es para que comience ya inmediatamente; y 1000 milisegundos para cada segundo se repita, se ejecute; de está manera se actualizara la hora cada segundo.
    }

    public boolean isFormato24() {
        return formato24;
    }

    public void setFormato24(boolean formato24) {
        this.formato24 = formato24;
    }

    public Alarma getAlarma() {
        return alarma;
    }

    public void setAlarma(Alarma alarma) {
        this.alarma = alarma;
    }

    public void addAlarmaListener(AlarmaListener alarmaListener) {
        this.alarmaListener = alarmaListener;
    }

    //Creamos está Clase para compabar las horas, minutos, segundos de la HoraActual y la HoraAlarma;
    //Para cuando coincidan pues todos los campos de Hora, minutos, segundos nos devuelva 'true' y active la Alarma.
    private boolean horasCoinciden(Date horaActual, Date horaAlarma) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(horaActual);
        int segActual, horasActual, minActual, segAlarma, horasAlarma, minAlarma;
        horasActual = calendar.get(Calendar.HOUR_OF_DAY);
        minActual = calendar.get(Calendar.MINUTE);
        segActual = calendar.get(Calendar.SECOND);
        
        calendar.setTime(horaAlarma);
        horasAlarma = calendar.get(Calendar.HOUR_OF_DAY);
        minAlarma = calendar.get(Calendar.MINUTE);
        segAlarma = calendar.get(Calendar.SECOND);
        
        if (horasActual == horasAlarma && minActual == minAlarma && segActual == segAlarma) {
            return true;
        } else {
            return false;
        }

    }

}
