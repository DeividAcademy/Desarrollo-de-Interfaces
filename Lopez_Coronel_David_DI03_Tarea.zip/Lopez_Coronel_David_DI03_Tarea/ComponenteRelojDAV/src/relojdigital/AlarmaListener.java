package relojdigital;

/**
 * @author David López Coronel.
 */

//Si creamos está Interface sin implementación.
// De está manera el usuario podrá decidir el código que quiera ejecutar.
public interface AlarmaListener {
    public void suenaAlarma();
}
