package relojdigital;

import java.io.Serializable;
import java.util.Date;


/**
 * @author David López Coronel.
 */

public class Alarma implements Serializable {
    //Creare dos campos, el de la hora de la Alarma y si esta activa.
    private Date horaAlarma;
    private boolean activa;
    
    public Alarma(Date horaAlarma, boolean activa) {
        this.horaAlarma = horaAlarma;
        this.activa = activa;
    }

    public Date getHoraAlarma() {
        return horaAlarma;
    }

    public void setHoraAlarma(Date horaAlarma) {
        this.horaAlarma = horaAlarma;
    }

    public boolean isActiva() {
        return activa;
    }

    public void setActiva(boolean activa) {
        this.activa = activa;
    }
    
    

 
            
    
}

