package relojdigital;

/**
 * @author David López Coronel.
 */
import java.awt.Component;
import java.beans.PropertyEditorSupport;
import java.util.Date;

public class AlarmaPropertyEditorSupport extends PropertyEditorSupport {
    private AlarmaPanel alarmaPanel = new AlarmaPanel();
    
    @Override
    //Le decimos que existe un editor de propiedades personalizado.
    public boolean supportsCustomEditor() {
        return true;
    }
    
    @Override
    //Le devolvemos el panel que nos va a permitir editar esa propiedad.
    public Component getCustomEditor() {
        return alarmaPanel;
    }
    
    @Override
    //Con esto ayudaremos a NetBeans a generar el código necesario para meter o añadir este componente en un Frame o un Diálogo.
    public String getJavaInitializationString() {
        Date horaAlarma = alarmaPanel.getSelectedValue().getHoraAlarma();
        boolean activa = alarmaPanel.getSelectedValue().isActiva();
        return "new relojdigital.Alarma(new java.util.Date("+horaAlarma.getTime()+"l),"+activa+")";
    }
    
    @Override
    //Devuelve el valor seleccionado por el usuario en el panel.
    public Object getValue() {
        return alarmaPanel.getSelectedValue();
    }
}

