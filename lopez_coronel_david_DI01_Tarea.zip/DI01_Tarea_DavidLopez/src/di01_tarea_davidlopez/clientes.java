package di01_tarea_davidlopez;

import java.awt.Toolkit;
import Atxy2k.CustomTextField.RestrictedTextField;
import java.awt.Component;
import java.net.URL;
import java.util.ResourceBundle;
import javax.swing.JOptionPane;
import org.jdesktop.application.Action;

/**
 *
 * @author David López
 */
public class clientes extends javax.swing.JDialog {

    /**
     * Creates new form clientes
     */
    public clientes(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        //Ajuste ventana y localizacion, apertura centrada, ect... 
        setLocationRelativeTo(null);

        //Restricciones de caracteres en las cajas de jTextField
        //Pues el método "RestrictedTextField" me va a permitir ajustar el ingreso de los caracteres de 0 a 9 en el campo del Teléfono.
        RestrictedTextField restrictedTelefono = new RestrictedTextField(this.txtTelefono);
        restrictedTelefono.setOnlyNums(true);
        //Pues el método "RestrictedTextField" me va a permitir ajustar el ingreso de los caracteres alfanuméricos en el campo del código.
        RestrictedTextField restrictedCodigo = new RestrictedTextField(this.txtCodigo);
        restrictedCodigo.setOnlyAlphaNumeric(true);
        //Pues el método "RestrictedTextField" me va a permitir ajustar el ingreso de los caracteres alfanuméricos en el campo del nombre.
        RestrictedTextField restrictedNombre = new RestrictedTextField(this.txtNombre);
        restrictedNombre.setOnlyAlphaNumeric(true);
        restrictedNombre.setAcceptSpace(true);
        //Pues el método "RestrictedTextField" me va a permitir ajustar el ingreso de los caracteres alfanuméricos en el campo del apellidos.
        RestrictedTextField restrictedApellidos = new RestrictedTextField(this.txtApellidos);
        restrictedApellidos.setOnlyAlphaNumeric(true);
        restrictedApellidos.setAcceptSpace(true);
        //Pues el método "RestrictedTextField" me va a permitir ajustar el ingreso de los caracteres alfanuméricos en el campo del direccion.
        RestrictedTextField restrictedDireccion = new RestrictedTextField(this.txtDireccion);
        restrictedDireccion.setOnlyAlphaNumeric(true);
        restrictedDireccion.setAcceptSpace(true);
        restrictedDireccion.setLimit(30);
        //Pues el método "RestrictedTextField" me va a permitir ajustar el ingreso de los caracteres de 0 a 9 en el campo de la tarifa.
        RestrictedTextField restrictedTarifa = new RestrictedTextField(this.txtTarifa);
        restrictedTarifa.setOnlyNums(true);
        //restrictedTarifa.setOnlyCustomCharacters(true);

        //Configuración de botones.
        btnAceptar.setEnabled(false);

    }

    //Mis métodos, para configuración de botones, requisitos, etc...
    //Con este método voy a poner las condiciones para ser rellenen los campos y no estén vacíos, antes de poder pulsar el botón registrar.
    public void habilitarBoton() {
        if (!txtCodigo.getText().isEmpty() && !txtNombre.getText().isEmpty() && !txtApellidos.getText().isEmpty()
                && !txtDireccion.getText().isEmpty() && !txtTelefono.getText().isEmpty()
                && !txtTarifa.getText().isEmpty() && !txtComercial.getText().isEmpty()
                && lbExcepcionTarifa.getText().isEmpty()) {
            btnAceptar.setEnabled(true);
        } else {
            btnAceptar.setEnabled(false);
        }

    }

    //Método para borrar los campos jTextField y etc.. 
    public void borrar() {
        txtCodigo.setText("");
        txtNombre.setText("");
        txtApellidos.setText("");
        txtDireccion.setText("");
        txtTelefono.setText("");
        txtTarifa.setText("");
        txtComercial.setText("");
        lbExcepcionTarifa.setText("");

    }

    //Método para reactivar o mejor dicho(desactivar) mi botón de registro, tras las pulsaciones y cierres del dialogo.
    public void btnAceptar() {
        btnAceptar.setEnabled(false);
    }

    //Método conversor String a Int en el campo Tarifa.
    public void conversor() {

        int convierte = Integer.parseInt(txtTarifa.getText());
        //System.out.println(convierte);
        if (convierte <= 100) {
            habilitarBoton();
            lbExcepcionTarifa.setText("");

        } else {
            btnAceptar.setEnabled(false);
            lbExcepcionTarifa.setText("¡Te pasaste del MaxTarifa!!");
        }
    }

    //Método para elegir Zona, activar CheckBox, etc..
    public void elegirLevante() {

        if (rbtnLevante.isSelected()) {

            checkBoxEstructura.setEnabled(true);
            checkBoxCimentacion.setEnabled(true);
            checkBoxAlbañileria.setEnabled(true);
            checkBoxFontaneria.setEnabled(true);
            checkBoxCarpinteria.setEnabled(true);
            checkBoxDecoracion.setEnabled(true);
        }
    }

    //Método para elegir Zona, activar CheckBox, etc..
    public void elegirCentro() {

        if (rbtnCentro.isSelected()) {

            checkBoxEstructura.setEnabled(false);
            checkBoxEstructura.setSelected(false);
            checkBoxCimentacion.setEnabled(false);
            checkBoxCimentacion.setSelected(false);
            checkBoxAlbañileria.setEnabled(true);
            checkBoxFontaneria.setEnabled(true);
            checkBoxCarpinteria.setEnabled(true);
            checkBoxDecoracion.setEnabled(true);
        }
    }

    //Método para elegir Zona, activar CheckBox, etc..
    public void elegirSur() {

        if (rbtnSur.isSelected()) {

            checkBoxEstructura.setEnabled(false);
            checkBoxEstructura.setSelected(false);
            checkBoxCimentacion.setEnabled(false);
            checkBoxCimentacion.setSelected(false);
            checkBoxAlbañileria.setEnabled(true);
            checkBoxFontaneria.setEnabled(true);
            checkBoxCarpinteria.setEnabled(true);
            checkBoxDecoracion.setEnabled(false);
            checkBoxDecoracion.setSelected(false);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bgZona = new javax.swing.ButtonGroup();
        lbClientes = new javax.swing.JLabel();
        pnCliente = new javax.swing.JPanel();
        lbTelefono = new javax.swing.JLabel();
        lbFecha = new javax.swing.JLabel();
        spinnerFecha = new javax.swing.JSpinner();
        txtTelefono = new javax.swing.JTextField();
        lbCodigo = new javax.swing.JLabel();
        txtCodigo = new javax.swing.JTextField();
        lbNombre = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        lbApellidos = new javax.swing.JLabel();
        txtApellidos = new javax.swing.JTextField();
        lbDireccion = new javax.swing.JLabel();
        txtDireccion = new javax.swing.JTextField();
        pnTarifa = new javax.swing.JPanel();
        txtTarifa = new javax.swing.JTextField();
        lbTarifa = new javax.swing.JLabel();
        lbExcepcionTarifa = new javax.swing.JLabel();
        pnZona = new javax.swing.JPanel();
        labelZona = new javax.swing.JLabel();
        rbtnLevante = new javax.swing.JRadioButton();
        rbtnCentro = new javax.swing.JRadioButton();
        rbtnSur = new javax.swing.JRadioButton();
        checkBoxEstructura = new javax.swing.JCheckBox();
        checkBoxCimentacion = new javax.swing.JCheckBox();
        checkBoxAlbañileria = new javax.swing.JCheckBox();
        checkBoxFontaneria = new javax.swing.JCheckBox();
        checkBoxCarpinteria = new javax.swing.JCheckBox();
        checkBoxDecoracion = new javax.swing.JCheckBox();
        pnComercial = new javax.swing.JPanel();
        txtComercial = new javax.swing.JTextField();
        labelComercial = new javax.swing.JLabel();
        separador2 = new javax.swing.JSeparator();
        separador3 = new javax.swing.JSeparator();
        separador1 = new javax.swing.JSeparator();
        lbIcon = new javax.swing.JLabel();
        pnBotones = new javax.swing.JPanel();
        btnAceptar = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();

        bgZona.add(rbtnLevante);
        bgZona.add(rbtnCentro);
        bgZona.add(rbtnSur);

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        org.jdesktop.application.ResourceMap resourceMap = org.jdesktop.application.Application.getInstance(di01_tarea_davidlopez.DI01_Tarea_DavidLopezApp.class).getContext().getResourceMap(clientes.class);
        setTitle(resourceMap.getString("Form.title")); // NOI18N
        setName("Form"); // NOI18N

        lbClientes.setFont(resourceMap.getFont("lbClientes.font")); // NOI18N
        lbClientes.setForeground(resourceMap.getColor("lbClientes.foreground")); // NOI18N
        lbClientes.setText(resourceMap.getString("lbClientes.text")); // NOI18N
        lbClientes.setName("lbClientes"); // NOI18N

        pnCliente.setName("pnCliente"); // NOI18N

        lbTelefono.setFont(resourceMap.getFont("lbTelefono.font")); // NOI18N
        lbTelefono.setText(resourceMap.getString("lbTelefono.text")); // NOI18N
        lbTelefono.setToolTipText(resourceMap.getString("lbTelefono.toolTipText")); // NOI18N
        lbTelefono.setName("lbTelefono"); // NOI18N

        lbFecha.setFont(resourceMap.getFont("lbFecha.font")); // NOI18N
        lbFecha.setText(resourceMap.getString("lbFecha.text")); // NOI18N
        lbFecha.setToolTipText(resourceMap.getString("lbFecha.toolTipText")); // NOI18N
        lbFecha.setName("lbFecha"); // NOI18N

        spinnerFecha.setModel(new javax.swing.SpinnerDateModel());
        spinnerFecha.setToolTipText(resourceMap.getString("spinnerFecha.toolTipText")); // NOI18N
        spinnerFecha.setEditor(new javax.swing.JSpinner.DateEditor(spinnerFecha, "dd/MM/yyyy"));
        spinnerFecha.setName("spinnerFecha"); // NOI18N

        txtTelefono.setText(resourceMap.getString("txtTelefono.text")); // NOI18N
        txtTelefono.setToolTipText(resourceMap.getString("txtTelefono.toolTipText")); // NOI18N
        txtTelefono.setName("txtTelefono"); // NOI18N
        txtTelefono.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtTelefonoKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtTelefonoKeyTyped(evt);
            }
        });

        lbCodigo.setFont(resourceMap.getFont("lbCodigo.font")); // NOI18N
        lbCodigo.setText(resourceMap.getString("lbCodigo.text")); // NOI18N
        lbCodigo.setToolTipText(resourceMap.getString("lbCodigo.toolTipText")); // NOI18N
        lbCodigo.setName("lbCodigo"); // NOI18N

        txtCodigo.setText(resourceMap.getString("txtCodigo.text")); // NOI18N
        txtCodigo.setToolTipText(resourceMap.getString("txtCodigo.toolTipText")); // NOI18N
        txtCodigo.setName("txtCodigo"); // NOI18N
        txtCodigo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtCodigoKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtCodigoKeyTyped(evt);
            }
        });

        lbNombre.setFont(resourceMap.getFont("lbNombre.font")); // NOI18N
        lbNombre.setText(resourceMap.getString("lbNombre.text")); // NOI18N
        lbNombre.setToolTipText(resourceMap.getString("lbNombre.toolTipText")); // NOI18N
        lbNombre.setName("lbNombre"); // NOI18N

        txtNombre.setText(resourceMap.getString("txtNombre.text")); // NOI18N
        txtNombre.setToolTipText(resourceMap.getString("txtNombre.toolTipText")); // NOI18N
        txtNombre.setName("txtNombre"); // NOI18N
        txtNombre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtNombreKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtNombreKeyTyped(evt);
            }
        });

        lbApellidos.setFont(resourceMap.getFont("lbApellidos.font")); // NOI18N
        lbApellidos.setText(resourceMap.getString("lbApellidos.text")); // NOI18N
        lbApellidos.setToolTipText(resourceMap.getString("lbApellidos.toolTipText")); // NOI18N
        lbApellidos.setName("lbApellidos"); // NOI18N

        txtApellidos.setText(resourceMap.getString("txtApellidos.text")); // NOI18N
        txtApellidos.setToolTipText(resourceMap.getString("txtApellidos.toolTipText")); // NOI18N
        txtApellidos.setName("txtApellidos"); // NOI18N
        txtApellidos.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtApellidosKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtApellidosKeyTyped(evt);
            }
        });

        lbDireccion.setFont(resourceMap.getFont("lbDireccion.font")); // NOI18N
        lbDireccion.setText(resourceMap.getString("lbDireccion.text")); // NOI18N
        lbDireccion.setToolTipText(resourceMap.getString("lbDireccion.toolTipText")); // NOI18N
        lbDireccion.setName("lbDireccion"); // NOI18N

        txtDireccion.setText(resourceMap.getString("txtDireccion.text")); // NOI18N
        txtDireccion.setToolTipText(resourceMap.getString("txtDireccion.toolTipText")); // NOI18N
        txtDireccion.setName("txtDireccion"); // NOI18N
        txtDireccion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDireccionActionPerformed(evt);
            }
        });
        txtDireccion.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtDireccionKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtDireccionKeyTyped(evt);
            }
        });

        pnTarifa.setName("pnTarifa"); // NOI18N

        txtTarifa.setText(resourceMap.getString("txtTarifa.text")); // NOI18N
        txtTarifa.setToolTipText(resourceMap.getString("txtTarifa.toolTipText")); // NOI18N
        txtTarifa.setName("txtTarifa"); // NOI18N
        txtTarifa.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtTarifaKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtTarifaKeyTyped(evt);
            }
        });

        lbTarifa.setFont(resourceMap.getFont("lbTarifa.font")); // NOI18N
        lbTarifa.setText(resourceMap.getString("lbTarifa.text")); // NOI18N
        lbTarifa.setToolTipText(resourceMap.getString("lbTarifa.toolTipText")); // NOI18N
        lbTarifa.setName("lbTarifa"); // NOI18N

        lbExcepcionTarifa.setFont(resourceMap.getFont("lbExcepcionTarifa.font")); // NOI18N
        lbExcepcionTarifa.setForeground(resourceMap.getColor("lbExcepcionTarifa.foreground")); // NOI18N
        lbExcepcionTarifa.setText(resourceMap.getString("lbExcepcionTarifa.text")); // NOI18N
        lbExcepcionTarifa.setToolTipText(resourceMap.getString("lbExcepcionTarifa.toolTipText")); // NOI18N
        lbExcepcionTarifa.setName("lbExcepcionTarifa"); // NOI18N

        javax.swing.GroupLayout pnTarifaLayout = new javax.swing.GroupLayout(pnTarifa);
        pnTarifa.setLayout(pnTarifaLayout);
        pnTarifaLayout.setHorizontalGroup(
            pnTarifaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnTarifaLayout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addComponent(lbTarifa)
                .addGap(18, 18, 18)
                .addComponent(txtTarifa, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(26, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnTarifaLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbExcepcionTarifa, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        pnTarifaLayout.setVerticalGroup(
            pnTarifaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnTarifaLayout.createSequentialGroup()
                .addContainerGap(27, Short.MAX_VALUE)
                .addGroup(pnTarifaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtTarifa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbTarifa))
                .addGap(1, 1, 1)
                .addComponent(lbExcepcionTarifa, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout pnClienteLayout = new javax.swing.GroupLayout(pnCliente);
        pnCliente.setLayout(pnClienteLayout);
        pnClienteLayout.setHorizontalGroup(
            pnClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnClienteLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lbCodigo)
                    .addComponent(lbNombre)
                    .addComponent(lbDireccion)
                    .addComponent(lbTelefono)
                    .addComponent(lbFecha))
                .addGap(26, 26, 26)
                .addGroup(pnClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(pnClienteLayout.createSequentialGroup()
                        .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 109, Short.MAX_VALUE)
                        .addComponent(lbApellidos)
                        .addGap(18, 18, 18)
                        .addComponent(txtApellidos, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(101, 101, 101))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, pnClienteLayout.createSequentialGroup()
                        .addGroup(pnClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(txtCodigo, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(spinnerFecha, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, pnClienteLayout.createSequentialGroup()
                                .addComponent(txtTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(102, 102, 102)
                                .addComponent(pnTarifa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(txtDireccion, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        pnClienteLayout.setVerticalGroup(
            pnClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnClienteLayout.createSequentialGroup()
                .addContainerGap(19, Short.MAX_VALUE)
                .addGroup(pnClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbCodigo)
                    .addComponent(txtCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(pnClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbNombre)
                    .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbApellidos)
                    .addComponent(txtApellidos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34)
                .addGroup(pnClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbDireccion)
                    .addComponent(txtDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(pnClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnClienteLayout.createSequentialGroup()
                        .addGap(34, 34, 34)
                        .addGroup(pnClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lbTelefono)
                            .addComponent(txtTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(pnClienteLayout.createSequentialGroup()
                        .addGap(7, 7, 7)
                        .addComponent(pnTarifa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(12, 12, 12)
                .addGroup(pnClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbFecha)
                    .addComponent(spinnerFecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        pnZona.setName("pnZona"); // NOI18N

        labelZona.setFont(resourceMap.getFont("labelZona.font")); // NOI18N
        labelZona.setText(resourceMap.getString("labelZona.text")); // NOI18N
        labelZona.setToolTipText(resourceMap.getString("labelZona.toolTipText")); // NOI18N
        labelZona.setName("labelZona"); // NOI18N

        rbtnLevante.setFont(resourceMap.getFont("rbtnLevante.font")); // NOI18N
        rbtnLevante.setText(resourceMap.getString("rbtnLevante.text")); // NOI18N
        rbtnLevante.setName("rbtnLevante"); // NOI18N
        rbtnLevante.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtnLevanteActionPerformed(evt);
            }
        });

        rbtnCentro.setFont(resourceMap.getFont("rbtnCentro.font")); // NOI18N
        rbtnCentro.setText(resourceMap.getString("rbtnCentro.text")); // NOI18N
        rbtnCentro.setName("rbtnCentro"); // NOI18N
        rbtnCentro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtnCentroActionPerformed(evt);
            }
        });

        rbtnSur.setFont(resourceMap.getFont("rbtnSur.font")); // NOI18N
        rbtnSur.setText(resourceMap.getString("rbtnSur.text")); // NOI18N
        rbtnSur.setName("rbtnSur"); // NOI18N
        rbtnSur.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtnSurActionPerformed(evt);
            }
        });

        checkBoxEstructura.setText(resourceMap.getString("checkBoxEstructura.text")); // NOI18N
        checkBoxEstructura.setEnabled(false);
        checkBoxEstructura.setName("checkBoxEstructura"); // NOI18N

        checkBoxCimentacion.setText(resourceMap.getString("checkBoxCimentacion.text")); // NOI18N
        checkBoxCimentacion.setEnabled(false);
        checkBoxCimentacion.setName("checkBoxCimentacion"); // NOI18N

        checkBoxAlbañileria.setText(resourceMap.getString("checkBoxAlbañileria.text")); // NOI18N
        checkBoxAlbañileria.setEnabled(false);
        checkBoxAlbañileria.setName("checkBoxAlbañileria"); // NOI18N

        checkBoxFontaneria.setText(resourceMap.getString("checkBoxFontaneria.text")); // NOI18N
        checkBoxFontaneria.setEnabled(false);
        checkBoxFontaneria.setName("checkBoxFontaneria"); // NOI18N

        checkBoxCarpinteria.setText(resourceMap.getString("checkBoxCarpinteria.text")); // NOI18N
        checkBoxCarpinteria.setEnabled(false);
        checkBoxCarpinteria.setName("checkBoxCarpinteria"); // NOI18N

        checkBoxDecoracion.setText(resourceMap.getString("checkBoxDecoracion.text")); // NOI18N
        checkBoxDecoracion.setEnabled(false);
        checkBoxDecoracion.setName("checkBoxDecoracion"); // NOI18N

        javax.swing.GroupLayout pnZonaLayout = new javax.swing.GroupLayout(pnZona);
        pnZona.setLayout(pnZonaLayout);
        pnZonaLayout.setHorizontalGroup(
            pnZonaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnZonaLayout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addComponent(labelZona)
                .addGap(29, 29, 29)
                .addGroup(pnZonaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(rbtnLevante)
                    .addComponent(rbtnCentro)
                    .addComponent(rbtnSur))
                .addGap(94, 94, 94)
                .addGroup(pnZonaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(pnZonaLayout.createSequentialGroup()
                        .addGroup(pnZonaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnZonaLayout.createSequentialGroup()
                                .addComponent(checkBoxEstructura)
                                .addGap(101, 101, 101)
                                .addComponent(checkBoxFontaneria))
                            .addGroup(pnZonaLayout.createSequentialGroup()
                                .addComponent(checkBoxAlbañileria)
                                .addGap(101, 101, 101)
                                .addComponent(checkBoxDecoracion)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(pnZonaLayout.createSequentialGroup()
                        .addComponent(checkBoxCimentacion)
                        .addGap(90, 90, 90)
                        .addComponent(checkBoxCarpinteria)
                        .addGap(132, 132, 132))))
        );
        pnZonaLayout.setVerticalGroup(
            pnZonaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnZonaLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(pnZonaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rbtnLevante)
                    .addComponent(checkBoxEstructura)
                    .addComponent(checkBoxFontaneria))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnZonaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rbtnCentro)
                    .addComponent(labelZona)
                    .addComponent(checkBoxCimentacion)
                    .addComponent(checkBoxCarpinteria))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnZonaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rbtnSur)
                    .addComponent(checkBoxAlbañileria)
                    .addComponent(checkBoxDecoracion))
                .addContainerGap(12, Short.MAX_VALUE))
        );

        pnComercial.setName("pnComercial"); // NOI18N

        txtComercial.setText(resourceMap.getString("txtComercial.text")); // NOI18N
        txtComercial.setToolTipText(resourceMap.getString("txtComercial.toolTipText")); // NOI18N
        txtComercial.setName("txtComercial"); // NOI18N
        txtComercial.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtComercialKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtComercialKeyTyped(evt);
            }
        });

        labelComercial.setFont(resourceMap.getFont("labelComercial.font")); // NOI18N
        labelComercial.setText(resourceMap.getString("labelComercial.text")); // NOI18N
        labelComercial.setToolTipText(resourceMap.getString("labelComercial.toolTipText")); // NOI18N
        labelComercial.setName("labelComercial"); // NOI18N

        javax.swing.GroupLayout pnComercialLayout = new javax.swing.GroupLayout(pnComercial);
        pnComercial.setLayout(pnComercialLayout);
        pnComercialLayout.setHorizontalGroup(
            pnComercialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnComercialLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(labelComercial)
                .addGap(31, 31, 31)
                .addComponent(txtComercial, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(62, Short.MAX_VALUE))
        );
        pnComercialLayout.setVerticalGroup(
            pnComercialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnComercialLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(pnComercialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labelComercial)
                    .addComponent(txtComercial, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(31, Short.MAX_VALUE))
        );

        separador2.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, resourceMap.getColor("separador2.border.highlightColor"), resourceMap.getColor("separador2.border.shadowColor"))); // NOI18N
        separador2.setName("separador2"); // NOI18N
        separador2.setPreferredSize(new java.awt.Dimension(0, 1));

        separador3.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, resourceMap.getColor("separador3.border.highlightColor"), resourceMap.getColor("separador3.border.shadowColor"))); // NOI18N
        separador3.setName("separador3"); // NOI18N
        separador3.setPreferredSize(new java.awt.Dimension(0, 1));

        separador1.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, resourceMap.getColor("separador1.border.highlightColor"), resourceMap.getColor("separador1.border.shadowColor"))); // NOI18N
        separador1.setName("separador1"); // NOI18N
        separador1.setPreferredSize(new java.awt.Dimension(0, 1));

        lbIcon.setIcon(resourceMap.getIcon("lbIcon.icon")); // NOI18N
        lbIcon.setText(resourceMap.getString("lbIcon.text")); // NOI18N
        lbIcon.setName("lbIcon"); // NOI18N

        pnBotones.setBorder(new javax.swing.border.LineBorder(resourceMap.getColor("pnBotones.border.lineColor"), 1, true)); // NOI18N
        pnBotones.setName("pnBotones"); // NOI18N

        javax.swing.ActionMap actionMap = org.jdesktop.application.Application.getInstance(di01_tarea_davidlopez.DI01_Tarea_DavidLopezApp.class).getContext().getActionMap(clientes.class, this);
        btnAceptar.setAction(actionMap.get("aceptar")); // NOI18N
        btnAceptar.setBackground(resourceMap.getColor("btnAceptar.background")); // NOI18N
        btnAceptar.setFont(resourceMap.getFont("btnAceptar.font")); // NOI18N
        btnAceptar.setForeground(resourceMap.getColor("btnAceptar.foreground")); // NOI18N
        btnAceptar.setText(resourceMap.getString("btnAceptar.text")); // NOI18N
        btnAceptar.setToolTipText(resourceMap.getString("btnAceptar.toolTipText")); // NOI18N
        btnAceptar.setName("btnAceptar"); // NOI18N

        btnCancelar.setAction(actionMap.get("cancelar")); // NOI18N
        btnCancelar.setBackground(resourceMap.getColor("btnCancelar.background")); // NOI18N
        btnCancelar.setFont(resourceMap.getFont("btnCancelar.font")); // NOI18N
        btnCancelar.setForeground(resourceMap.getColor("btnCancelar.foreground")); // NOI18N
        btnCancelar.setText(resourceMap.getString("btnCancelar.text")); // NOI18N
        btnCancelar.setToolTipText(resourceMap.getString("btnCancelar.toolTipText")); // NOI18N
        btnCancelar.setName("btnCancelar"); // NOI18N

        javax.swing.GroupLayout pnBotonesLayout = new javax.swing.GroupLayout(pnBotones);
        pnBotones.setLayout(pnBotonesLayout);
        pnBotonesLayout.setHorizontalGroup(
            pnBotonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnBotonesLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(btnAceptar)
                .addGap(18, 18, 18)
                .addComponent(btnCancelar)
                .addContainerGap(24, Short.MAX_VALUE))
        );
        pnBotonesLayout.setVerticalGroup(
            pnBotonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnBotonesLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(pnBotonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAceptar)
                    .addComponent(btnCancelar))
                .addContainerGap(18, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(separador1, javax.swing.GroupLayout.PREFERRED_SIZE, 880, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(separador3, javax.swing.GroupLayout.PREFERRED_SIZE, 880, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(separador2, javax.swing.GroupLayout.PREFERRED_SIZE, 880, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(17, 17, 17)
                                .addComponent(pnComercial, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(pnBotones, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(41, 41, 41)
                                .addComponent(lbIcon)
                                .addGap(74, 74, 74)
                                .addComponent(lbClientes))
                            .addComponent(pnCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(pnZona, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(162, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lbIcon)
                    .addComponent(lbClientes))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(separador1, javax.swing.GroupLayout.PREFERRED_SIZE, 1, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(pnCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(separador2, javax.swing.GroupLayout.PREFERRED_SIZE, 1, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(pnZona, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(separador3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(pnComercial, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pnBotones, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtDireccionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDireccionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDireccionActionPerformed

    private void txtCodigoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCodigoKeyTyped
        // Con este método voy a limitar el número de caracteres que vamos a ingresar en el jTextField a 5 caracteres y usare el "KeyTyped" para así solo podamos ingresar alfanuméricos.
        if (txtCodigo.getText().length() >= 5) {
            // El parámetro ".consume" nos va a borrar los caracteres sobrantes que queramos añadir al jTextField una vez sobre pasemos el límite de Max 5 caracteres.
            evt.consume();
            // Este parámetro "Toolkit" nos va a emitir un sonido al llegar al tope de números de caracteres Max.
            Toolkit.getDefaultToolkit().beep();
        }
    }//GEN-LAST:event_txtCodigoKeyTyped

    private void txtNombreKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNombreKeyTyped
        if (txtNombre.getText().length() >= 10) {
            evt.consume();
            Toolkit.getDefaultToolkit().beep();
        }
    }//GEN-LAST:event_txtNombreKeyTyped

    private void txtApellidosKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtApellidosKeyTyped
        if (txtApellidos.getText().length() >= 10) {
            evt.consume();
            Toolkit.getDefaultToolkit().beep();
        }
    }//GEN-LAST:event_txtApellidosKeyTyped

    private void txtDireccionKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtDireccionKeyTyped
        if (txtDireccion.getText().length() >= 30) {
            evt.consume();
            Toolkit.getDefaultToolkit().beep();
        }
    }//GEN-LAST:event_txtDireccionKeyTyped

    private void txtComercialKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtComercialKeyTyped
        if (txtComercial.getText().length() >= 10) {
            evt.consume();
            Toolkit.getDefaultToolkit().beep();
        }
    }//GEN-LAST:event_txtComercialKeyTyped

    private void txtTarifaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTarifaKeyTyped
        if (txtTarifa.getText().length() >= 3) {
            evt.consume();
            Toolkit.getDefaultToolkit().beep();
        }
    }//GEN-LAST:event_txtTarifaKeyTyped

    private void txtTelefonoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTelefonoKeyTyped
        // TODO add your handling code here:
        if (txtTelefono.getText().length() >= 9) {
            evt.consume();
            Toolkit.getDefaultToolkit().beep();
        }
    }//GEN-LAST:event_txtTelefonoKeyTyped

    private void txtCodigoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCodigoKeyReleased
        habilitarBoton();
    }//GEN-LAST:event_txtCodigoKeyReleased

    private void txtNombreKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNombreKeyReleased
        habilitarBoton();
    }//GEN-LAST:event_txtNombreKeyReleased

    private void txtApellidosKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtApellidosKeyReleased
        habilitarBoton();
    }//GEN-LAST:event_txtApellidosKeyReleased

    private void txtDireccionKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtDireccionKeyReleased
        habilitarBoton();
    }//GEN-LAST:event_txtDireccionKeyReleased

    private void txtTelefonoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTelefonoKeyReleased
        habilitarBoton();
    }//GEN-LAST:event_txtTelefonoKeyReleased

    private void txtTarifaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTarifaKeyReleased
        habilitarBoton();
        conversor();
    }//GEN-LAST:event_txtTarifaKeyReleased

    private void txtComercialKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtComercialKeyReleased
        habilitarBoton();
    }//GEN-LAST:event_txtComercialKeyReleased

    private void rbtnLevanteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtnLevanteActionPerformed
        // De esta manera vamos a darle la funcionalidad o acción que va a desencadenar tras seleccionar botón Levante.
        //Previamente creado el método para la configuración de los checkBox de productos y severcicios a poder seleccionar.
        if (evt.getSource() == rbtnLevante) {
            elegirLevante();
        }
    }//GEN-LAST:event_rbtnLevanteActionPerformed

    private void rbtnCentroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtnCentroActionPerformed
        // De esta manera vamos a darle la funcionalidad o acción que va a desencadenar tras seleccionar botón Centro.
        //Previamente creado el método para la configuración de los checkBox de productos y severcicios a poder seleccionar.
        if (evt.getSource() == rbtnCentro) {
            elegirCentro();
        }
    }//GEN-LAST:event_rbtnCentroActionPerformed

    private void rbtnSurActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtnSurActionPerformed
        // De esta manera vamos a darle la funcionalidad o acción que va a desencadenar tras seleccionar botón Sur.
        //Previamente creado el método para la configuración de los checkBox de productos y severcicios a poder seleccionar.
        if (evt.getSource() == rbtnSur) {
            elegirSur();
        }
    }//GEN-LAST:event_rbtnSurActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(clientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(clientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(clientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(clientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                clientes dialog = new clientes(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    @Action//Métodos, 'Acciones' para cerrar el jDialog de clientes, y sus recpectivos métodos para borrar los campos etc.
    public void cancelar() {
        //Si mis campos 'jTextField' están vacios, asi lo voy a comprobar para cuando pulce cancelar la acción me cierre el diálogo clientes.
        if (txtCodigo.getText().isEmpty() && txtNombre.getText().isEmpty() && txtApellidos.getText().isEmpty()
                && txtDireccion.getText().isEmpty() && txtTelefono.getText().isEmpty()
                && txtTarifa.getText().isEmpty() && txtComercial.getText().isEmpty()) {
            dispose();
        } else {
            int salida = JOptionPane.showConfirmDialog(null,
                    "¿Estas Seguro?", "Realmente deseas salir!",
                    JOptionPane.OK_CANCEL_OPTION);
            if (salida == 0) {
                dispose();
                btnAceptar();//Para resetear mi botón Registrar y lo devuelva a su valor inicial desactivado.
                borrar();//Para vaciar los campos jTextField.
            }
        }

    }

    @Action//Método para configurar los requisitos para realizar el registro.
    public void aceptar() {
        borrar();
        dispose();
        btnAceptar();        
        JOptionPane.showMessageDialog(null, "Registro Guardado");
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup bgZona;
    private javax.swing.JButton btnAceptar;
    private javax.swing.JButton btnCancelar;
    private javax.swing.JCheckBox checkBoxAlbañileria;
    private javax.swing.JCheckBox checkBoxCarpinteria;
    private javax.swing.JCheckBox checkBoxCimentacion;
    private javax.swing.JCheckBox checkBoxDecoracion;
    private javax.swing.JCheckBox checkBoxEstructura;
    private javax.swing.JCheckBox checkBoxFontaneria;
    private javax.swing.JLabel labelComercial;
    private javax.swing.JLabel labelZona;
    private javax.swing.JLabel lbApellidos;
    private javax.swing.JLabel lbClientes;
    private javax.swing.JLabel lbCodigo;
    private javax.swing.JLabel lbDireccion;
    private javax.swing.JLabel lbExcepcionTarifa;
    private javax.swing.JLabel lbFecha;
    private javax.swing.JLabel lbIcon;
    private javax.swing.JLabel lbNombre;
    private javax.swing.JLabel lbTarifa;
    private javax.swing.JLabel lbTelefono;
    private javax.swing.JPanel pnBotones;
    private javax.swing.JPanel pnCliente;
    private javax.swing.JPanel pnComercial;
    private javax.swing.JPanel pnTarifa;
    private javax.swing.JPanel pnZona;
    private javax.swing.JRadioButton rbtnCentro;
    private javax.swing.JRadioButton rbtnLevante;
    private javax.swing.JRadioButton rbtnSur;
    private javax.swing.JSeparator separador1;
    private javax.swing.JSeparator separador2;
    private javax.swing.JSeparator separador3;
    private javax.swing.JSpinner spinnerFecha;
    private javax.swing.JTextField txtApellidos;
    private javax.swing.JTextField txtCodigo;
    private javax.swing.JTextField txtComercial;
    private javax.swing.JTextField txtDireccion;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtTarifa;
    private javax.swing.JTextField txtTelefono;
    // End of variables declaration//GEN-END:variables
}
